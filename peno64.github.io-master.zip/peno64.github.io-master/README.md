# peno kodi addons

This method is obsolete. Please use the repository https://peno64.github.io/repository.peno64/
<br>
See <a href="https://kodi.wiki/view/Add-on_manager">https://kodi.wiki/view/Add-on_manager</a>
